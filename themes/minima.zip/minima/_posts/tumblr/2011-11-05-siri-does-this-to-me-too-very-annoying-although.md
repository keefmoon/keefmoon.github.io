---
layout: post
title: Siri Time
date: '2011-11-05T19:33:54+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/12381391616/siri-does-this-to-me-too-very-annoying-although
---
Siri does this to me too. Very annoying. Although, if I say “What time is it in London?” I get the answer.

> ![Siri conversation about time](http://66.media.tumblr.com/tumblr_lu44tsZxdC1r4eoiuo1_1280.png)

(Source: [shitthatsirisays](http://shitthatsirisays.tumblr.com/post/12377100993))

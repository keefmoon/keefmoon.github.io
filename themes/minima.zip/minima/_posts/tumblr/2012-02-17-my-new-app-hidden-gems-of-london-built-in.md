---
layout: post
title: Hidden Gems of London
date: '2012-02-17T21:32:09+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/17782716220/my-new-app-hidden-gems-of-london-built-in
---

![Gems of London screenshot]({{ site.url }}/tumblr_files/tumblr_lzk3tlymj71r4drs9o1_1280.png)

My new App, Hidden Gems of London, built in collaboration with Victor Keegan, is now live in the App Store!

[http://keef.me/LDNGems](http://keef.me/LDNGems)

Our App shows you a London that isn’t in the guide books, highlighting hidden places and features.

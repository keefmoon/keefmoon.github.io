---
layout: post
title: Great iOS Bluetooth Tutorial
date: '2013-01-14T23:59:06+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/40555606817/great-ios-bluetooth-tutorial
---
[Great iOS Bluetooth Tutorial](http://invasivecode.tumblr.com/post/39707371281/core-bluetooth-for-ios-core-bluetooth-was)

Looking forward to trying out some Bluetooth goodness.

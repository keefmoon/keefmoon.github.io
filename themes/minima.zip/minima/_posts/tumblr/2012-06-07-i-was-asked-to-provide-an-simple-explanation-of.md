---
layout: post
title: Anatomy of a Request
date: '2012-06-07T10:06:30+01:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/24600141210/i-was-asked-to-provide-an-simple-explanation-of
---
I was asked to provide an simple explanation of how an iPhone App interacts with, and retrieves data from, a web service, such as we use at Hotels.com. It seems to have been really helpful for some non-technical people here, and so I thought is might be helpful for others.
Created on my journey home one day, using [OmniGraffle for iPad](http://t.umblr.com/redirect?z=http%3A%2F%2Fitunes.apple.com%2Fgb%2Fapp%2Fomnigraffle%2Fid363225984%3Fmt%3D8&t=Y2Q5NWEzOWMxY2I2NTFiODFkYTVlNTgyNDIyNzE4OWRjMTFlNDM4Mix5SXcySHp4WQ%3D%3D&b=t%3AFWXc4HC6zAL6f3DZ4FKykw&m=1).

![Anatomy of a request diagram]({{ site.url }}/tumblr_files/tumblr_m58pauizt01r4drs9o1_1280.png)

---
layout: post
title: AudioFuel in the Top 50 Innovative UK Apps
date: '2012-02-24T10:44:23+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/18183127542/audiofuel-in-the-top-50-innovative-uk-apps
---
My AudioFuel App has been listed as in The App Side’s list of 50 Innovative App from the UK. The report is embedded below.

[Apps Report](http://www.scribd.com/doc/82564623)

<iframe class="scribd_iframe_embed" frameborder="0" height="600" id="doc_92882" scrolling="no" src="http://www.scribd.com/embeds/82564623/content?start_page=1&amp;view_mode=list" width="100%"></iframe>

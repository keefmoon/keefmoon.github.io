---
layout: post
title: 'Yield Thought: I swapped my MacBook for an iPad+Linode'
date: '2011-11-04T12:43:51+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/12324094907/yield-thought-i-swapped-my-macbook-for-an
---
[Yield Thought: I swapped my MacBook for an iPad+Linode](http://yieldthought.com/post/12239282034/swapped-my-macbook-for-an-ipad)

> On September 19th, I said goodbye to my trusty MacBook Pro and started developing exclusively on an iPad + Linode 512. This is the surprising story of a month spent working in the cloud.
It all started when I bought my first MacBook a couple of years ago. Frustrated by the inconsistent…

---
layout: post
title: 'Lightbox Blog: Lightbox is joining Facebook!'
date: '2012-05-15T19:54:20+01:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/23113972657/lightbox-blog-lightbox-is-joining-facebook
---
I used to sit next to these guys. Congratulations Lightbox!

[lightboxapp](http://blog.lightbox.com/post/23107101360/lightbox-is-joining-facebook):

> We started Lightbox because we were excited about creating new services built primarily for mobile, especially for the Android and HTML5 platforms, and we’re honored that millions of you have downloaded the Lightbox Photos app and shared your experiences with the Lightbox community.
Today,…

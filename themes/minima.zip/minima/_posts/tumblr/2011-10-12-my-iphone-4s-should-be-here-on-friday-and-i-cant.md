---
layout: post
title: Real World Demo of Siri Personal Assistant on an Apple iPhone 4S
date: '2011-10-12T11:59:07+01:00'
tags:
- iPhone4S
- Apple
- iPhone
- Siri
- iOS
tumblr_url: http://keefmoon.tumblr.com/post/11350474971/my-iphone-4s-should-be-here-on-friday-and-i-cant
---

My iPhone 4S should be here on Friday and I can’t wait :)

> Real World Demo of Siri Personal Assistant on an Apple iPhone 4S
> <iframe width="560" height="315" src="https://www.youtube.com/embed/MKRwV3DTVLo" frameborder="0" allowfullscreen></iframe>

(Source: [Laughing Squid](http://laughingsquid.com/demo-of-siri-on-apple-iphone-4s/))

---
layout: post
title: A Rainbow At Its Peak
date: '2012-01-16T16:35:41+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/15950807698/a-rainbow-at-its-peak
---
Nice graph. Will be interesting to see the update in 5 or 10 years.

[parislemon](http://parislemon.com/post/15950097492/a-rainbow-at-its-peak):

>Horace Dediu presents yet another amazing way to look at the rapidly evolving computer industry (here are Dediu’s other fascinating looks of the past few days).
The PC looks like a rainbow at its peak.
The Macintosh looks like a roller coaster with a misleading small first hill that tricks riders.
Android, iPhone, and iPad look like fireworks just taking off…
> ![Graph of units shipped per year](http://65.media.tumblr.com/tumblr_lxwfx3cwMz1qz4gev.png)

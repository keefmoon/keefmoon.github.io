---
layout: post
title: Sparrow on iOS
date: '2011-11-24T11:32:00+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/13249552246/sparrowios
---

> ![iPhone on table showing SparrowMail](http://65.media.tumblr.com/tumblr_lu393nRMhV1qbptnpo1_500.jpg)

I LOVE Sparrow mail App on OSX, and the idea of it on the iPhone is very exciting. I’ve never liked the default Mail App, and wondered why no-one was making mail clients on iOS. I assumed the Apple would claim that it duplicated built-in functionality, maybe they changed the policy recently, since the GMail App is now out.
sparrowmail:

>As seen on The Verge and Business Insider, here is a preview of Sparrow for iPhone.

(Source: [sparrowmail](http://sparrowmail.tumblr.com/post/12283842323/sparrowios))

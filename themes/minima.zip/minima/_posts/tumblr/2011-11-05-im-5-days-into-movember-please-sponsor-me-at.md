---
layout: post
title: 5 days into Movember
date: '2011-11-05T18:03:28+00:00'
tags:
- movember
tumblr_url: http://keefmoon.tumblr.com/post/12377698522/im-5-days-into-movember-please-sponsor-me-at
---
![5 days into Movember]({{ site.url }}/tumblr_files/tumblr_lu78tsMv361r4drs9o1_1280.png)
I’m 5 days into Movember. Please sponsor me at [http://mobro.co/keefmoon](http://mobro.co/keefmoon) and see all the pics at [http://keef.me/fbmopics](http://keef.me/fbmopics)

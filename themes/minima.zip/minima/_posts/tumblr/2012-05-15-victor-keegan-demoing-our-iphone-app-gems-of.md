---
layout: post
title: Demoing Gems of London
date: '2012-05-15T19:32:10+01:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/23112989252/victor-keegan-demoing-our-iphone-app-gems-of
---
[Victor Keegan](http://twitter.com/vickeegan) demoing our iPhone App Gems of London

<iframe width="400" height="300"  id="youtube_iframe" src="https://www.youtube.com/embed/HdhzwDdNWps?feature=oembed&enablejsapi=1&origin=http://safe.txmblr.com&wmode=opaque" frameborder="0" allowfullscreen></iframe>

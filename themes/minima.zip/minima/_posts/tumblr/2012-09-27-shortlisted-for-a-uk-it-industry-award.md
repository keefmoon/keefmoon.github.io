---
layout: post
title: Shortlisted for a UK IT Industry Award
date: '2012-09-27T13:30:50+01:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/32390759735/shortlisted-for-a-uk-it-industry-award
---
The Hotels.com iOS team (which I am currently a part of) has been shortlisted for a UK IT Industry Award in the category of IT Project Team of the Year.

[UK IT Industry Awards Shortlist](http://www.ukitindustryawards.co.uk/static/2012-shortlist)

I’m told the award is specifically for the iPad App project, which we as a team have been improving over the last year.
You can download [Hotels.com HD for your iPad from the App Store](https://itunes.apple.com/us/app/hotels.com-hd/id461327349?mt=8)

![Hotels.com iPad app screenshot]({{ site.url }}/tumblr_files/hotels-com-ipad.png)

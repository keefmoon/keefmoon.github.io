---
layout: post
title: Beanbags have arrived at the Mobile Roadie office
date: '2011-10-21T13:31:39+01:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/11730256398/beanbags-have-arrived-at-the-mobile-roadie-office
---
![Keith sitting on a beanbag]({{ site.url }}/tumblr_files/beanbag.jpg)
Beanbags have arrived at the Mobile Roadie office :)

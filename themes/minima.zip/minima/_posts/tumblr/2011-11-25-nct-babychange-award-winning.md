---
layout: post
title: NCT Babychange - Award Winning!
date: '2011-11-25T15:21:35+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/13300140434/nct-babychange-award-winning
---
My App for the NCT, NCT Babychange, won an award on Wednesday! Best Mobile Solution at the APA International Content Marketing Awards.

Details here [http://keef.me/NCTAPAAward](http://keef.me/NCTAPAAward )

App here [http://keef.me/nctapp](http://keef.me/nctapp)

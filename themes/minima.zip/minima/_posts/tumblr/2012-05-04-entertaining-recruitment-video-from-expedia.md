---
layout: post
title: Entertaining Recruitment Video from Expedia
date: '2012-05-04T13:12:11+01:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/22378888416/entertaining-recruitment-video-from-expedia
---
Entertaining recruitment video from Expedia, featuring the building I currently work in for Expedia/Hotels.com

<iframe width="400" height="225"  id="youtube_iframe" src="https://www.youtube.com/embed/4ZGOHRrXfJk?feature=oembed&enablejsapi=1&origin=http://safe.txmblr.com&wmode=opaque" frameborder="0" allowfullscreen></iframe>

---
layout: post
title: Last day at Mobile Roadie
date: '2011-11-25T13:19:00+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/13297239598/today-is-my-last-day-at-mobile-roadie-my-time
---

![Mobile Roadie banner]({{ site.url }}/tumblr_files/tumblr_lv7x0dvcU71r4drs9o1_1280.jpg)

Today is my last day at Mobile Roadie.

My time with Mobile Roadie has been amazing, we’ve won awards, we’ve [been to Downing Street]({{ site.url }}/2011/10/24/its-not-often-you-get-to-say-that-your-job-took.html), and we’ve [built up the UK office]({{ site.url }}/2011/10/21/beanbags-have-arrived-at-the-mobile-roadie-office.html) into a really cool place to work.

But it’s time for me to move on. I’m leaving the warm comfy embrace of permanent employment and into the harsh cold reality of freelance work. I’ve got a initial contract to get me going, which is very exciting, and I’ll post more about it when I’m up and running.

Thank you to everyone at [Mobile Roadie](https://mobileroadie.com/) for teaching me so much over the past year, and allowing me to be part of an amazing team. Special thanks to [Stephen O'Reilly](http://twitter.com/steoreilly) and Ash Lim for making Mobile Roadie UK as awesome, fun and friendly as it is, and to Steve Schroeder for being one of the smartest guys I know and teaching me so much.

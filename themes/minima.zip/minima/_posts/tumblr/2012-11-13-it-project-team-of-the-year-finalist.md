---
layout: post
title: IT Project Team of the Year Finalist
date: '2012-11-13T16:35:12+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/35640135831/it-project-team-of-the-year-finalist
---
The Hotels.com iOS team has been [named as a finalist](http://www.bcs.org/content/ConWebDoc/47713) for the BCS IT Industry Awards 2012, in the category IT Project Team of the Year.

I [wrote about being shortlisted]({{ site.url }}/2012/09/27/shortlisted-for-a-uk-it-industry-award.html), but we have made it to the final, and representatives will be attending a black tie awards ceremony tomorrow (Wed 14th Nov).

Fingers crossed!

---
layout: post
title: What I have to do to get Siri to tell me the time
date: '2012-02-06T22:45:15+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/17174089880/what-i-have-to-do-to-get-siri-to-tell-me-the
---

<iframe width="560" height="315" src="https://www.youtube.com/embed/-1v6BnkT4X0" frameborder="0" allowfullscreen></iframe>

Siri is awesome and I use it all the time, but sometime it seems to over complicate things. 

Before Siri there was Voice Control, it did simple things like playing music, voice dialing and tell you the time. However in some instances, Siri seems like a step backwards. 

For something as simple as asking for the time, instead of just repeating the iPhone’s current time, it now requires an Internet connection and uses your location to determine your time zone…. except that it doesn’t seem to be able to tie your, very accurate, location to a particular time zone.

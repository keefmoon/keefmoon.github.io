---
layout: post
title: Free Scrum eBook
date: '2012-01-16T21:28:43+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/15967431142/free-scrum-ebook
---
I’ve been wanting to learn about the Scrum framework for software development for a while, and I now find myself knee-deep in it with my current iOS contract.
It’s a lot less scary than it seemed and here is a free eBook with practical implementation examples:

[http://www.infoq.com/minibooks/scrum-xp-from-the-trenches](http://www.infoq.com/minibooks/scrum-xp-from-the-trenches)

---
layout: post
title: No. 10 Downing Street
date: '2011-10-24T22:10:21+01:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/11876966038/its-not-often-you-get-to-say-that-your-job-took
---
![Keith and Stephen at No. 10]({{ site.url }}/tumblr_files/tumblr_ltl9h9kOEo1r4drs9o1_1280.jpg)
It’s not often you get to say that your job took you to No. 10 Downing Street :)
Stephen and I chatted to the the Prime Minister’s digital team about Apps.

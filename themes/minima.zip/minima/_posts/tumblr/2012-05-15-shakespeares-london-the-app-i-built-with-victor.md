---
layout: post
title: Shakespeare's London in Time Out
date: '2012-05-15T21:18:37+01:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/23118552066/shakespeares-london-the-app-i-built-with-victor
---
Shakespeare's London, the App I built with [Victor Keegan](http://twitter.com/vickeegan) was featured in this week’s Time Out.

![Shakespeare's London in TimeOut]({{ site.url }}/tumblr_files/tumblr_m42z31mv381r4drs9o1_1280.png)

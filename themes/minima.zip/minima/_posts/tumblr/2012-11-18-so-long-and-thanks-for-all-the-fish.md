---
layout: post
title: So long, and thanks for all the fish.
date: '2012-11-18T23:27:56+00:00'
tags: []
tumblr_url: http://keefmoon.tumblr.com/post/36023952695/so-long-and-thanks-for-all-the-fish
---
![Hotels.com banner]({{ site.url }}/tumblr_files/hotels-com-banner.jpg)

Friday was my last day at [Hotels.com](http://www.hotels.com), I’m leaving for a new contract at the BBC.

I have been working there for nearly a year and have enjoyed my time immensely. I have made some really good friends and greatly improved my understanding of software development practices, and I put that down to the great working environment and the skill and patience of my colleagues.

My team bought me the most amazing leaving present ever, THE BIGGEST MUG IN THE WORLD, which they all signed. Thanks all :)

![Keith with the biggest mug in the world]({{ site.url }}/tumblr_files/8197190561_cbff33918f_k.jpg)
